<?php
return [
    'adminEmail' => 'admin@example.com',
    'gender'=>[
        0=>'Ayol',
        1=>'Erkak',
    ],
    'user.status'=>[
        1=>'Aktiv',
        0=>'Deaktiv',
        -1=>'O`chirilgan'
    ],
    'status'=>[
        1=>'Aktiv',
        0=>'Deaktiv',
        -1=>'O`chirilgan'
    ],
    'status.confirm'=>[
        1=>'Jarayonda',
        0=>'Rad qilindi',
        2=>'Tasdiqlandi',
    ],
    'status.grafic'=>[
        1=>'To`lanmagan',
        2=>'Yopilgan',
        3=>'Muddati o`tgan',
    ],
    'credit_pay_type'=>[
        1=>'Har oyda',
//        3=>'Har chorakda',
//        12=>'Har yilda'
    ]
];
